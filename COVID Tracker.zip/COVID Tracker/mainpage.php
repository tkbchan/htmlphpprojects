<!DOCTYPE html>
<html lang="en">
<head>
  <title>Home</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="mainpagestyle.css">
  
<script type="text/javascript"> //disables back functionality during login
        function preventBack() { window.history.forward(); }
        setTimeout("preventBack()", 0);
        window.onunload = function () { null };
</script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="mainpage.html">COVID 19 Tracker</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="mainpage.html">Home</a></li>
        <li><a href="covidmap.html">Map</a></li>
        <li><a href="newspage.html">News</a></li>
        <li><a href="#">About Us</a></li>
		<li><a href="contactus.html">Contact Us</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="index.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
  
<div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-2 sidenav">
      <p><a href="#">Link</a></p>
      <p><a href="#">Link</a></p>
      <p><a href="#">Link</a></p>
    </div>
    <div class="col-sm-8 text-left"> 
      <h1>Welcome to COVID 19 Tracker</h1>
      <p>Our proposed solution is to create a web application in which you will be required to create an account that will track your location when going out (will be activated by the user), you'll see a map with locations with high Covid-19 cases (updated frequently), and notify if you have come across someone in proximity that has been reported positive of covid-19 using your GPS location data.  </p>
      <hr>
      <h3>Test</h3>
      <p></p>
    </div>
    <div class="col-sm-2 sidenav">
      <div class="well">
        <p>Gusto mo ba yumaman?</p>
      </div>
      <div class="well">
        <p>Ang tae ko ay masarap</p>
      </div>
    </div>
  </div>
</div>

<footer class="container-fluid text-center">
  <p>© 2021</p>
</footer>

</body>
</html>
