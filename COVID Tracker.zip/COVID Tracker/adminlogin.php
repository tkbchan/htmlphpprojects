<!DOCTYPE html>
<html>
<head>
  <title>COVID 19 Tracker</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="style2.css">
</head>
<script type="text/javascript"> //disables back functionality during login
        function preventBack() { window.history.forward(); }
        setTimeout("preventBack()", 0);
        window.onunload = function () { null };
</script>
<div class = "FORM">
         
         <?php
            $msg = '';
            
            if (isset($_POST['login']) && !empty($_POST['username']) 
               && !empty($_POST['password'])) {
				
               if ($_POST['username'] == 'admin' && 
                  $_POST['password'] == 'admin123') {
                  $_SESSION['valid'] = true;
                  $_SESSION['timeout'] = time();
                  $_SESSION['username'] = 'admin';
                  
                header("Location: admin.php"); //add redirect page here!!
               }else {
                  $msg = 'Invalid username or password';
               }
            }
         ?>
   </div> <!-- /container -->


<body>
<form class = "form-signin" role = "form" action = "<?php echo htmlspecialchars($_SERVER['PHP_SELF']); 
            ?>" method = "post">
  <div class="modal-dialog text-center">
    <div class="col-sm-8 main-section">
      <div class="modal-content">
        <div class="col-12 user-img">
          <img src="lock.png">
        </div>
        <div class="col-12 user-name">
          <h1>Admin Login</h1>
        </div>
        <div class="col-12 form-input">
          <form>
            <div class="form-group">
              <input type="text" name="username" class="form-control" placeholder="Username">
            </div>
            <div class="form-group">
              <input type="password" name="password" class="form-control" placeholder="Password">
            </div>
            <button type="submit" class="btn btn-success" name = "login">Login</button>
          </form>
        </div>
        <div class="col-12 link-part">
		  <a href="index.php">Click here if you're not an admin</a>
        </div>
      </div>
    </div>
  </div>
</form>
</body>
</html>