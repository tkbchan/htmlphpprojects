<!DOCTYPE html>
<html>
<head>
  <title>COVID 19 Tracker</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="style2.css">
</head>
<script type="text/javascript">
        function preventBack() { window.history.forward(); }
        setTimeout("preventBack()", 0);
        window.onunload = function () { null };
</script>
<?php
// Create database connection using config file
include_once("connect.php");
 
// GEt all users data from database
$result = mysqli_query($conn, "SELECT * FROM users ORDER BY id DESC");
?>

<body>

	<table class="table table-dark">
 
    <tr>
        <th>Name</th> <th>Email</th> <th>Username</th> <th>Password</th>
    </tr>
    <?php  
    while($user_data = mysqli_fetch_array($result)) {         
        echo "<tr>";
        echo "<td>".$user_data['name']."</td>";
        echo "<td>".$user_data['email']."</td>";
		echo "<td>".$user_data['username']."</td>";  
        echo "<td>".$user_data['password']."</td>";    
    }
    ?>
    </table>
	

<div class="footer">
<p><a href="admin.php">Return to Administrator Tools</a></p>
</div>

</body>
</html>