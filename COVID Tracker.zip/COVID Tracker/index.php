<!DOCTYPE html>
<html>
<head>
  <title>COVID 19 Tracker</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<script type="text/javascript">
        function preventBack() { window.history.forward(); }
        setTimeout("preventBack()", 0);
        window.onunload = function () { null };
</script>

<body>

  <div class="modal-dialog text-center">
    <div class="col-sm-8 main-section">
      <div class="modal-content">
        <div class="col-12 user-img">
          <img src="person2.png">
        </div>
        <div class="col-12 user-name">
          <h1>User Login</h1>
        </div>
        <div class="col-12 form-input">
          <form method="POST" action="index.php">
            <div class="form-group">
              <input type="text" name="username" class="form-control" placeholder="Username">
            </div>
            <div class="form-group">
              <input type="password" name="password" class="form-control" placeholder="Password">
            </div>
            <button type="submit" class="btn btn-success" name = "login">Login</button>
<?php  
require('connect.php');

if (isset($_POST['username']) and isset($_POST['password'])){
	
// Assigning POST values to variables.
$username = $_POST['username'];
$password = $_POST['password'];
$password = md5($password);

// CHECK FOR THE RECORD FROM TABLE
$query = "SELECT * FROM `users` WHERE username='$username' and password='$password'";
 
$result = mysqli_query($conn, $query) or die(mysqli_error($conn));
$count = mysqli_num_rows($result);

if ($count == 1){

	//redirection page after loggin in
	header('location:mainpage.html');


}else{
echo "<font color = 'red'>INVALID USER CREDENTIALS!";
}
}

?>
          </form>
        </div>
        <div class="col-12 link-part">
		  <a href="register.php">Create a New Account</a></br>
		  <a href="adminlogin.php">Click here if you're an admin</a>
        </div>
      </div>
    </div>
  </div>







</body>
</html>



