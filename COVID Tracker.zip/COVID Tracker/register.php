<!DOCTYPE html>
<html>
<head>
  <title>Create a New Account</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>



<body>



<form method="post" action="register.php">
  <div class="modal-dialog text-center">
    <div class="col-sm-9 main-section">
      <div class="modal-content">
        <div class="col-12 user-img">
          <img src="person2.png">
        </div>
        <div class="col-12 user-name">
          <h1>Create an Account</h1>
        </div>
        <div class="col-12 form-input">
          <form>
			<div class="form-group">
              <input type="text" name="fname" class="form-control" placeholder="First Name" autocomplete="off" required>
			  <span class="error"></span>
			  <span class="text-danger"><?php if (isset($name_error)) echo $name_error; ?></span>
            </div>
			<div class="form-group">
              <input type="text" name="lname" class="form-control" placeholder="Last Name" autocomplete="off" required>
			  <span class="error"></span>
			  <span class="text-danger"><?php if (isset($name_error)) echo $name_error; ?></span>
            </div>
            <div class="form-group">
              <input type="email" name="email" class="form-control" placeholder="Enter email" required>
			  <span class="error"></span>
			  <span class="text-danger"><?php if (isset($email2_error)) echo $email2_error; ?></span>
            </div>
			<div class="form-group">
              <input type="text" name="username" class="form-control" placeholder="Enter Username" autocomplete="off" required>
			  <span class="error"></span>
			  <span class="text-danger"><?php if (isset($uname_error)) echo $uname_error; ?></span>
            </div>
            <div class="form-group">
              <input type="password" name="password" class="form-control" placeholder="Enter Password" autocomplete="off" required>
			  <span class="error"></span>
	          <span class="text-danger"><?php if (isset($pword_error)) echo $pword_error; ?></span>
            </div>
			<div class="form-group">
              <input type="password" name="password2" class="form-control" placeholder="Confirm Password" autocomplete="off" required>
			  <span class="error"></span>
	          <span class="text-danger"><?php if (isset($pword2_error)) echo $pword2_error; ?></span>
            </div>
            <button type="submit" class="btn btn-success" name = "submit" value = "Submit">Register</button>
			<?php
include("connect.php");


if(isset($_POST['submit'])){
$error = true;
	//add information to db
	$pword = mysqli_real_escape_string($conn, $_POST['password']);
	$pword2 = mysqli_real_escape_string($conn, $_POST['password2']);
	$uname = mysqli_real_escape_string($conn, $_POST['username']);
	$name = ($_POST['fname'])." ".($_POST['lname']);
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$pword = md5($pword);
	
	//verification
		if (!preg_match("/^[a-zA-Z ]+$/",$name)) {
			$name_error = "Name must contain only alphabets and space";
        }
         if(!filter_var($email,FILTER_VALIDATE_EMAIL)) {
			$email_error = "Please Enter Valid Email ID";
        }
		 if(strlen($pword) < 6) {
			$pword_error = "Password must be minimum of 6 characters";
        }
		 if($_POST['password'] != $_POST['password2']) {
            $pword2_error = "Password and Confirm Password doesn't match";
        }
		
		// first check the database to make sure 
		// a user does not already exist with the same username and/or email
		$user_check_query = "SELECT * FROM users WHERE username='$uname' OR email='$email' LIMIT 1";
		$result = mysqli_query($conn, $user_check_query);
		$user = mysqli_fetch_assoc($result);
  
		if ($user) { // if user exists
			if ($user['username'] == $uname) {
				$uname_error = "Username already exists.";
			}
			 if ($user['email'] == $email) {
				$email_error2 = "Email already taken.";
			}
			
		}
		else{
			
			if(mysqli_query($conn, "INSERT INTO users (name, email, username, password) VALUES ('$name', '$email', '$uname', '$pword')")){
				echo "</br><font color = 'white'> Successfully Registered! <a href='index.php'>Click here</a></br>";
			} else {
				echo "Error: " . $sql . "" . mysqli_error($conn);
			}
		
		}
	}

?>
			
          </form>
        </div>
		<div class="col-12 link-part">
		  <a href="index.php">I already have an account</a>
        </div>
      </div>
    </div>
  </div>

</form>





</body>
</html>