<!DOCTYPE html>
<html>
<head>
  <title>Administrator Tools</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="style2.css">
</head>

<script type="text/javascript">
        function preventBack() { window.history.forward(); }
        setTimeout("preventBack()", 0);
        window.onunload = function () { null };
</script>

<div class="modal-dialog text-center">
    <div class="col-sm-8 main-section">
      <div class="modal-content">
        <div class="col-12 user-img">
          <img src="lock.png">
        </div>
        <div class="col-12 user-name">
          <h1>Administrator Tools</h1>
        </div>
        <div class="col-12 form-input">
          <form>
            <div class="form-group">
              <button type="button" class="btn btn-success" onclick="window.location.href = 'indexadmin.php';">Manage Users</button>
            </div>
            <div class="form-group">
              <button type="button" class="btn btn-success" onclick="window.location.href = 'adminlogin.php';">Logout</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>