<?php include 'sendemail.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Home</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="mainpagestyle.css">
</head>
<script type="text/javascript">
        function preventBack() { window.history.forward(); }
        setTimeout("preventBack()", 0);
        window.onunload = function () { null };
</script>
<body>
 <!--alert messages start-->
    <?php echo $alert; ?>
 <!--alert messages end-->
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="mainpage.html">COVID 19 Tracker</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="mainpage.html">Home</a></li>
        <li><a href="covidmap.html">Map</a></li>
        <li><a href="newspage.html">News</a></li>
        <li><a href="#">Live Cases by DOH</a></li>
		<li class="active"><a href="#">Contact Us</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="index.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
     
  <!-- Container (Contact Section) -->
<div class="container-fluid bg-grey">
  <h2 class="text-center"></h2>
  <div class="row content">
    <div class="col-sm-5">
      <p>Contact us and we'll get back to you within 24 hours.</p>
      <p><span class="glyphicon glyphicon-map-marker"></span> Metro Manila, Philippines</p>
      <p><span class="glyphicon glyphicon-phone"></span> +63 9174637551</p>
      <p><span class="glyphicon glyphicon-envelope"></span> pandemictracker.ph@gmail.com</p>
    </div>
    <div class="col-sm-7">
	<form class="contact" action="" method="post">
      <div class="row">
        <div class="col-sm-6 form-group">
          <input type="text" name="name" class="form-control" placeholder="Your Name" required>
        </div>
        <div class="col-sm-6 form-group">
          <input type="email" name="email" class="form-control" placeholder="Your Email" required>
        </div>
      </div>
      <textarea class="form-control" name="message" rows="15" placeholder="Your Message" required></textarea><br>
      <div class="row">
        <div class="col-sm-12 form-group">
          <button class="btn btn-success" type="submit" name="submit" value="Send">Send</button>
        </div>
      </div>
	</form>
    </div>
  </div>
</div>

    <script type="text/javascript">
    if(window.history.replaceState){
      window.history.replaceState(null, null, window.location.href);
    }
    </script>

</div>

<footer class="container-fluid text-center">
  <p>© 2021</p>
</footer>

</body>
</html>
