<!DOCTYPE html>
<html lang="en">
<head>
  <title>Shipping Summary</title>
  <meta charset="utf-8">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <style>
    @import url('https://fonts.googleapis.com/css?family=Barlow+Semi+Condensed');

body {
	font-family: 'Barlow Semi Condensed', sans-serif;
	background: url(https://miro.medium.com/max/3002/1*dP81IJq-tGFxy1rIK3RYsg.png) no-repeat center center fixed;
	background-size: cover;
}
.user-img {
	margin-top: -50px;
}
.user-img img {
	height: 100px;
	width: 100px;
}
.main-section {
	margin: 0 auto;
	margin-top: 150px;
	padding: 0;
}
.modal-content {
	background-color: #3e4444;
	opacity: .95;
}
.user-name {
	margin: 10px 0;
}
.user-name h1 {
	font-size: 30px;
	color: #ccd6d7;
}
.form-input button {
	width: 100%;
	margin-bottom: 20px;
}
.btn-success {
	background-color: #2ecc71;
	border: 1px solid #2ecc71;
}
.btn-success:hover {
	background-color: #27ae60;
	border: 1px solid #27ae60;
}
.link-part {
	background-color: #ecf0f1;
	padding: 15px;
	border-radius: 0 0 5px 5px;
	border-top: 1px solid #c2c2c2;
}
  </style>
</head>
<body>
<div class="modal-dialog text-center">
    <div class="col-sm-8 main-section">
      <div class="modal-content">
        <div class="col-12 user-img">
          <img src="https://www.freeiconspng.com/thumbs/cart-icon/black-shopping-cart-icon-22.png">
        </div>
        <div class="col-12 user-name">
          <h1>ORDER SUMMARY</h1>
        </div>
        <div class="col-12 link-part">
<?php
class Checkout {
  public $name;
  public $number;
  public $address;
  public $card;
  public $discount;
#VVVV getters and setters here VVVVV
  function set_name($name) {
    $this->name = $name;
  }
  function get_name() {
    return $this->name;
  }
  function set_number($number) {
    $this->number = $number;
  }
  function get_number() {
    return $this->number;
  }
  function set_address($address) {
    $this->address = $address;
  }
  function get_address() {
    return $this->address;
  }
  function set_card($card) {
    $this->card = $card;
  }
  function get_card() {
    return $this->card;
  }
  function set_discount($discount) {
    $this->discount = $discount;
  }
  function get_discount() {
    return $this->discount;
  }
  function set_totalcart($totalcart) {
    $this->totalcart = (int)$totalcart;
  }
  function get_totalcart() {
    return $this->totalcart;
  }
}

$name = new Checkout();
$number = new Checkout();
$address = new Checkout();
$card = new Checkout();
$discount = new Checkout();
$totalcart = new Checkout();
$name->set_name($_POST['name']);
$number->set_number($_POST['number']);
$address->set_address($_POST['address']);
$card->set_card($_POST['card']);
$discount->set_discount($_POST['discount']);
$totalcart->set_totalcart($_POST['totalprice']);

$disc = $discount->get_discount();
$product = $totalcart->get_totalcart();

echo "Full Name: ",$name->get_name();
echo "<br>";
echo "Contact Number: ",$number->get_number();
echo "<br>";
echo "Shipping Address: ",$address->get_address();
echo "<br>";
echo "Card Type: ",$card->get_card();
echo "<br>";
echo "Discount Privilege: ",$discount->get_discount();
echo "<br>";
echo "Total Price: PHP ",$totalcart->get_totalcart();
echo "<br>";
#VVVV This is where the magic happens, and by that I meant calculations. VVVVV
if ($disc == "Senior Citizen") {
  $seniortax1 = $totalcart->get_totalcart() * 0.12;
  $seniortax2 = $totalcart->get_totalcart() + $seniortax1;
  $senior1 = $seniortax2 * 0.20;
  $senior2 = $seniortax2 - $senior1;
  $seniorwship = $senior2 + 45;

  echo "Shipping fee: PHP 45.00";
  echo "<br>";
  echo "<font color = Red>Total Price (VAT, Discount, Shipping included): PHP ",$seniorwship;
  
} elseif ($disc == "PWD") {
  $PWDtax1 = $totalcart->get_totalcart() * 0.12;
  $PWDtax2 = $totalcart->get_totalcart() + $PWDtax1;
  $PWD1 = $PWDtax2 * 0.20;
  $PWD2 = $PWDtax2 - $PWD1;
  $PWDwship = $PWD2 + 45;

  echo "Shipping fee: PHP 45.00";
  echo "<br>";
  echo "<font color = Red>Total Price (VAT, Discount, Shipping included): PHP ",$PWDwship;
  
} elseif ($disc == "Student") {
  $Studtax1 = $totalcart->get_totalcart() * 0.12;
  $Studtax2 = $totalcart->get_totalcart() + $Studtax1;
  $Stud1 = $Studtax2 * 0.20;
  $Stud2 = $Studtax2 - $Stud1;
  $Studwship = $Stud2 + 45;

  echo "Shipping fee: PHP 45.00";
  echo "<br>";
  echo "<font color = Red>Total Price (VAT, Discount, Shipping included): PHP ",$Studwship;
} elseif ($disc == "None") {
  $nonetax1 = $totalcart->get_totalcart() * 0.12;
  $nonetax2 = $totalcart->get_totalcart() + $nonetax1;
  
  $nonewship = $nonetax2 + 45;
  
  echo "Shipping fee: PHP 45.00";
  echo "<br>";
  echo "<font color = Red>Total Price (VAT, Discount, Shipping included): PHP ",$nonewship;
} elseif ($disc == "Discount Privileges") {
  echo "You didn't select a discount privilege. Try Again";
} else {
  echo "Try Again!";
}
?>
		</div>
      </div>
    </div>
  </div>

<footer class="container-fluid text-center">
  <p><font color = white>Timothy Kyle B. Chan OL151<font color = white></p>
</footer>



</body>
</html>