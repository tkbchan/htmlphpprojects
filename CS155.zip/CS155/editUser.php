<?php
// include database connection file
include_once("connect.php");
 
// Check if form is submitted for user update, then redirect to homepage after update
if(isset($_POST['Update']))
{	
	$id = $_POST['id'];
	
	$email=$_POST['email'];
	$pword=$_POST['password'];
	$pword = md5($pword);
		
	// update user data
	$result = mysqli_query($conn, "UPDATE users SET email='$email' ,password='$pword' WHERE email='$email', password='$pword'");
	
	// Redirect to homepage to display updated user in list
	header("Location: useracct.php");
}
?>
<?php
// Display selected user data based on id
// Getting id from url
$id = $_GET['id'];
 
// Fetch user data based on id
$result = mysqli_query($conn, "SELECT * FROM users WHERE username = ['username']");
 
while($user_data = mysqli_fetch_array($result))
{
	$email = $user_data['email'];
	$pword = $user_data['password'];
}
?>
<html>
<head>	
<title>Edit User Data</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="design.css">
</head>
 
<body style="background-color:black">
	<a href="welcome.html">Home</a>
	<br/><br/>
	
	<form name="update_user" method="post" action="userlogin.php">
		<table border="0">
			<tr> 
				<td style="color:white">Email</td>
				<td><input type="text" name="email" placeholder=<?php echo $email;?>></td>
			</tr>
			<tr> 
				<td style="color:white">Password</td>
				<td><input type="text" name="password" placeholder=<?php echo $pword;?>></td>
			</tr>
			<tr>
				<td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
				<td><input type="submit" name="Update" value="Update"></td>
			</tr>
		</table>
	</form>
</body>
</html>