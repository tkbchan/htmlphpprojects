<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<title>Upload File</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css">
</head>
<body style="background-color:black">
<nav class="navbar navbar-expand-sm bg-warning navbar-dark">
  <a class="navbar-brand" href="welcome.html"><i class="fas fa-home"></i></a>
  <ul class="navbar-nav">
  <li class="nav-item">
  <form method = "post" enctype = "multipart/form-data">
		<input type="file" name="myfile"/>
		<button name = "btn" class="btn btn-dark">Upload</button>
  </form>
  </li>
  </ul>
</nav>

	<?php
	$dbh = new PDO("mysql:host=localhost;dbname=demo", "root", "");
	if(isset($_POST['btn'])){
	

		$name = $_FILES['myfile']['name'];
		$type = $_FILES['myfile']['type'];
		$data = file_get_contents($_FILES['myfile']['tmp_name']);
		$stmt = $dbh->prepare("insert into invoice values('',?,?,?)");
		$stmt->bindParam(1,$name);
		$stmt->bindParam(2,$type);
		$stmt->bindParam(3,$data);
		$stmt->execute();

		
	}
	?>

	<header>
	</header>
	<br>
	<p></p>
	<ol>
	<?php
	$stat = $dbh->prepare("select * from invoice");
	$stat->execute();
	while($row = $stat->fetch()){
		echo "<li><a target='_blank' href='view-invoice.php?id=".$row['id']."'>".$row['name']."</a><br/>
		<embed src='data:".$row['mime'].";base64,".base64_encode($row['data'])."' width='200'/></li>";
	}
	?>
	</ol>
</body>
</html>