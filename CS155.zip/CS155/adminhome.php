

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="loginstyle.css">
<title>Admin Home</title>
</head>
   <script type="text/javascript">
        function preventBack() { window.history.forward(); }
        setTimeout("preventBack()", 0);
        window.onunload = function () { null };
    </script>

<body style="background-color: black";>
<div class="login-box">
    <div class="text-box">
      <h1>Administrator Tools</h1>
	<div class="text-box">
      <button type="button" class="btn btn-warning" onclick="window.location.href = 'indexadmin.php';">Manage Users</button>
	<div class="text-box">
      <button type="button" class="btn btn-warning" onclick="window.location.href = 'viewfileadmin.php';">Manage Files</button>
    <div class="text-box">
      <button type="button" class="btn btn-warning" onclick="window.location.href = 'admin.php';">Logout</button>
</nav>
</body>

</html>