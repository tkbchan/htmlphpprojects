<?php
// DB connection
include_once("connect.php");
 
// Get info from DB
$result = mysqli_query($conn, "SELECT * FROM users ORDER BY id DESC");
?>
 
<html>
<head>    
    <title>Manage Users</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
 
<body style="background-color: black";>
<nav class="navbar navbar-expand-sm bg-warning navbar-dark">
  <a class="navbar-brand" href="welcome.html"><i class="fas fa-home"></i></a>
  <ul class="navbar-nav">
    <li class="nav-item">
      <a style="color:white"></i>Manage Account</a>
    </li>
  </ul>
</nav>
    <table class="table table-dark table-hover">
 
    <tr>
        <th>Name</th> <th>Email</th> <th>Username</th> <th>Password</th> <th>Phone</th>  <th>Update</th>
    </tr>
    <?php  
    while($user_data = mysqli_fetch_array($result)) {         
        echo "<tr>";
        echo "<td>".$user_data['name']."</td>";
        echo "<td>".$user_data['email']."</td>";
		echo "<td>".$user_data['username']."</td>";  
        echo "<td>".$user_data['password']."</td>";    
		echo "<td>".$user_data['phone']."</td>";   
        echo "<td><a href='editUser.php?id=$user_data[username]'>Edit</a></td></tr>";    
	}
    ?>
    </table>
	<br>
</body>
</html>