<!DOCTYPE html>
<html lang="ph">
<head>
  <title>Admin Login Page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="loginstyle.css">
</head>
<script type="text/javascript"> //disables back functionality during login
        function preventBack() { window.history.forward(); }
        setTimeout("preventBack()", 0);
        window.onunload = function () { null };
</script>
<body style="background-color: black";>

<div class="login-box">
  <h1>GHING TRADING ADMIN</h2>
  <div class = "FORM">
         
         <?php
            $msg = '';
            
            if (isset($_POST['login']) && !empty($_POST['username']) 
               && !empty($_POST['password'])) {
				
               if ($_POST['username'] == 'admin' && 
                  $_POST['password'] == 'ghingtrading') {
                  $_SESSION['valid'] = true;
                  $_SESSION['timeout'] = time();
                  $_SESSION['username'] = 'admin';
                  
                header("Location: adminhome.php"); //add redirect page here!!
               }else {
                  $msg = 'Invalid username or password';
               }
            }
         ?>
   </div> <!-- /container -->
<form class = "form-signin" role = "form" action = "<?php echo htmlspecialchars($_SERVER['PHP_SELF']); 
            ?>" method = "post">
    <div class="form-group">
		<div class="textbox">
		<i class="fas fa-user"></i>
		<input type="text" placeholder="Bansag" id="usr" name="username" autocomplete="off" required>
    </div>
    <div class="form-group">
		<div class="textbox">
		<i class="fas fa-lock"></i>
		<input type="password" placeholder="Password" id="pwd" name="password" autocomplete="off" required>
    </div>
    <button type="submit" class="btn btn-warning" name = "login">Pumasok</button>
  </form>
  <center><a href = "index-fil.html" title = "Home Page" style="color:white">Bumalik sa pinanggalingan.</center></p1>
</div>

</body>
</html>