
<!DOCTYPE HTML>  
<html>
<head>
<title>Add Users</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="design.css">
<style>
.error {color: #FF0000;}
</style>
</head>
<body style="background-color:black">  

<?php
include("connect.php");


if(isset($_POST['submit'])){
$error = true;
	//add information to db
	$pword = mysqli_real_escape_string($conn, $_POST['password']);
	$pword2 = mysqli_real_escape_string($conn, $_POST['password2']);
	$uname = mysqli_real_escape_string($conn, $_POST['username']);
	$name = ($_POST['fname'])." ".($_POST['lname']);
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$tel = $_POST['tel'];
	$pword = md5($pword);
	
	//verification
		if (!preg_match("/^[a-zA-Z ]+$/",$name)) {
			$name_error = "Name must contain only alphabets and space";
        }
         if(!filter_var($email,FILTER_VALIDATE_EMAIL)) {
			$email_error = "Please Enter Valid Email ID";
        }
		 if(strlen($pword) < 6) {
			$pword_error = "Password must be minimum of 6 characters";
        }      
         if(strlen($tel) < 11) {
             $tel_error = "Mobile number must be minimum of 11 characters";
        }
		 if($_POST['password'] != $_POST['password2']) {
            $pword2_error = "Password and Confirm Password doesn't match";
        }
		
		// first check the database to make sure 
		// a user does not already exist with the same username and/or email
		$user_check_query = "SELECT * FROM users WHERE username='$uname' OR email='$email' LIMIT 1";
		$result = mysqli_query($conn, $user_check_query);
		$user = mysqli_fetch_assoc($result);
  
		if ($user) { // if user exists
			if ($user['username'] == $uname) {
				$uname_error = "Username already exists.";
			}
			 if ($user['email'] == $email) {
				$email_error2 = "Email already taken.";
			}
			
		}
		else{
			
			if(mysqli_query($conn, "INSERT INTO users (name, email, username, password, phone) VALUES ('$name', '$email', '$uname', '$pword', '$tel')")){
				echo "Successfully Registered! <a href='indexadmin.php'>Click here</a>";
			} else {
				echo "Error: " . $sql . "" . mysqli_error($conn);
			}
		
		}
	}

?>


<form method="post" action="members.php">
  <div class="container">
    <h1 style="color:orange">ADD NEW USERS</h1>
    <p>Fill in the following fields.</p>
    <hr>
	
    <label for="first_name"><b>First Name</b></label>
    <input type="text" name="fname" placeholder="First Name" autocomplete="off" required>
	<span class="error"></span>
	<span class="text-danger"><?php if (isset($name_error)) echo $name_error; ?></span>
	
    <label for="last_name"><b>Last Name</b></label>
    <input type="text" name="lname" placeholder="Last Name" autocomplete="off" required>
	<span class="error"></span>
	<span class="text-danger"><?php if (isset($name_error)) echo $name_error; ?></span>

    <label for="email"><b>E-mail</b></label>
    <input type="text" name="email" placeholder="johndoe@domain.com" autocomplete="off" required>
	<span class="error"></span>
	<span class="text-danger"><?php if (isset($email2_error)) echo $email2_error; ?></span>
	
	<label for="phone"><b>11-Digit Phone Number</b></label>
	<input type="text" name="tel" placeholder="11 digit mobile number" autocomplete="off" required>
	<span class="error"></span>
	<span class="text-danger"><?php if (isset($tel_error)) echo $tel_error; ?></span>

	<label for="user"><b>Username</b></label>
	<input type="text" name="username">
	<span class="error"></span>
	<span class="text-danger"><?php if (isset($uname_error)) echo $uname_error; ?></span>
	
	<label for="pass"><b>Password</b></label>
	<input type="password" name="password" autocomplete="off">
	<span class="error"></span>
	<span class="text-danger"><?php if (isset($pword_error)) echo $pword_error; ?></span>
	
	<label for="confpass"><b>Confirm Password</b></label>
	<input type="password" name="password2" autocomplete="off">
	<span class="error"></span>
	<span class="text-danger"><?php if (isset($pword2_error)) echo $pword2_error; ?></span>
    <hr>

    <button type="submit" name="submit" value="Submit" class="registerbtn">Register</button>

  </div>

</form>
<br><br>
<footer>
<center><a href="adminhome.php">ADMIN HOME</a></center>
</footer>

</body>
</html>