<!DOCTYPE html>
<html>
<head>
<title>User Login</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="loginstyle.css">
</head>

<body style="background-color:black";>

<?php  
require('connect.php');

if (isset($_POST['username']) and isset($_POST['password'])){
	
// Assigning POST values to variables.
$username = $_POST['username'];
$password = $_POST['password'];
$password = md5($password);

// CHECK FOR THE RECORD FROM TABLE
$query = "SELECT * FROM `users` WHERE username='$username' and password='$password'";
 
$result = mysqli_query($conn, $query) or die(mysqli_error($conn));
$count = mysqli_num_rows($result);

if ($count == 1){

	//redirection page after loggin in
	header('location:welcome.html');

}else{
echo "INVALID USER CREDENTIALS!";
}
}
?>
<div class="login-box">
<h1>GHING TRADING USER</h1>
<form method="POST" action="userlogin.php">
  <div class="form-group">
  <div class="textbox">
  <i class="fas fa-user"></i>
  <input type="text" placeholder="Username" name="username" autocomplete="off">
  </div>
  <div class="form-group">
  <div class="textbox">
  <i class="fas fa-lock"></i>
  <input type="password" placeholder="Password" name="password">
  </div>
  <button type="submit" class="btn btn-warning" name = "login">Login</button>
</form>

  <center><a href = "index.html" title = "Home Page" style="color:white">Return to Homepage.</center></p1>

</div>
</body>

</html>