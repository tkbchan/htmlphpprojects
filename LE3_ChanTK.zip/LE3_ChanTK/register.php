<!DOCTYPE html>
<html>
<head>
  <title>Create a New Account</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>
<style>
@import url('https://fonts.googleapis.com/css?family=Barlow+Semi+Condensed');

body {
	font-family: 'Barlow Semi Condensed', sans-serif;
	background: url(https://wallpaperaccess.com/full/1155043.jpg) no-repeat center center fixed;
	background-size: cover;
}
.user-img {
	margin-top: -50px;
}
.user-img img {
	height: 100px;
	width: 100px;
}
.main-section {
	margin: 0 auto;
	margin-top: 150px;
	padding: 0;
}
.modal-content {
	background-color: #3e4444;
	opacity: .95;
}
.user-name {
	margin: 10px 0;
}
.user-name h1 {
	font-size: 30px;
	color: #ccd6d7;
}
.form-input button {
	width: 100%;
	margin-bottom: 20px;
}
.btn-success {
	background-color: #2ecc71;
	border: 1px solid #2ecc71;
}
.btn-success:hover {
	background-color: #27ae60;
	border: 1px solid #27ae60;
}
.link-part {
	background-color: #ecf0f1;
	padding: 15px;
	border-radius: 0 0 5px 5px;
	border-top: 1px solid #c2c2c2;
}
</style>

<body>

<form method="POST" action="register.php">
  <div class="modal-dialog text-center">
    <div class="col-sm-9 main-section">
      <div class="modal-content">
        <div class="col-12 user-img">
          <img src="https://lh3.google.com/u/0/d/1lFeBffciNIOiZdc2KeXnIw2IIa6zNjD4=w984-h915-iv1">
        </div>
        <div class="col-12 user-name">
          <h1>Create an Account</h1>
        </div>
        <div class="col-12 form-input">
          <form>
			<div class="form-group">
              <input type="text" name="username" class="form-control" placeholder="Enter Username" autocomplete="off" required>
            </div>
            <div class="form-group">
              <input type="password" name="password" class="form-control" placeholder="Enter Password" autocomplete="off" required>
            </div>
            <button type="submit" class="btn btn-danger" name = "submit" value = "Register">Register</button>
<?php
if($_SERVER["REQUEST_METHOD"] == "POST")
{
$username = ($_POST['username']);
$password = ($_POST['password']);
$bool = true;
$db_name = "deliverydb"; 
$db_username = "root"; 
$db_pass = ""; 
$db_host = "localhost"; 
$con = mysqli_connect("$db_host","$db_username","$db_pass", "$db_name") or 
die(mysqli_error()); //Connect to server
$query = "SELECT * from users";
$results = mysqli_query($con, $query); //Query the users table
while($row = mysqli_fetch_array($results)) //display all rows from query
{
$table_users = $row['username']; // the first username row is passed on to $table_users, and so on until the query is finished
if($username == $table_users) // checks if there are any matching fields
{
$bool = false; // sets bool to false
Print '<script>alert("Username has been taken!");</script>'; //Prompts the user
Print '<script>window.location.assign("register.php");</script>'; // redirects to register.php
}
}
if($bool) // checks if bool is true
{
mysqli_query($con, "INSERT INTO users (username, password) VALUES 
('$username','$password')"); //Inserts the value to table users
Print '<script>alert("Successfully Registered!");</script>'; // Prompts the user
Print '<script>window.location.assign("register.php");</script>'; // redirects to register.php
}
}
?>	
          </form>
        </div>
		<div class="col-12 link-part">
		  <a href="login.php">Have an Account? Login Here!</a>
        </div>
      </div>
    </div>
  </div>

</form>





</body>
</html>