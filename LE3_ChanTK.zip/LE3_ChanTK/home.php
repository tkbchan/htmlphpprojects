<html lang="en">
<head>
  <title>My Food Delivery Store</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <style>
  </style>
</head>
<?php
session_start(); //starts the session
if($_SESSION['user']){ //checks if user is logged in
}
else{
 header("location:index.php"); // redirects if user is not logged in
}
$user = $_SESSION['user']; //assigns user value
?>
<body>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <!-- Brand/logo -->
  <a class="navbar-brand" href="#">Home Page</a>
  
  <!-- Links -->
  <ul class="navbar-nav ml-auto">
    <li class="nav-item">
      <a class="nav-link" href="logout.php">Logout</a>
    </li>
  </ul>
</nav>

<div class="container p-3 my-3 border">
  <h1>Hello <?php Print "$user"?>!</h1>
  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
  Add to List
  </button>
</div>

<div class="container">
  <h2>My List</h2>            
  <table class="table table-dark table-hover">
    <thead>
      <tr>
        <th>Id</th>
		<th>Details</th>
		<th>Post Time</th>
		<th>Edit Time</th>
		<th>Edit</th>
		<th>Delete</th>
		<th>Public Post</th>
      </tr>
<?php
 $con = mysqli_connect("localhost", "root", "", "deliverydb") or die(mysqli_error()); //Connect to server
 $query = mysqli_query($con, "Select * from list"); // SQL Query
 while($row = mysqli_fetch_array($query))
 {
 Print "<tr>";
 Print '<td align="center">'. $row['id'] . "</td>";
 Print '<td align="center">'. $row['details'] . "</td>";
 Print '<td align="center">'. $row['date_posted']. " - ". $row['time_posted']."</td>";
 Print '<td align="center">'. $row['date_edited']. " - ". $row['time_edited']. "</td>";
 Print '<td align="center"><a href="edit.php?id='. $row['id'] .'">edit</a> </td>';
 Print '<td align="center"><a href="#" onclick="myFunction('.$row['id'].')">delete</a> </td>';
 Print '<td align="center">'. $row['public']. "</td>";
 Print "</tr>";
 }
?>
    </thead>
  </table>
</div>

<script>
 function myFunction(id)
 {
 var r=confirm("Are you sure you want to delete this record?");
 if (r==true)
 {
 window.location.assign("delete.php?id=" + id);
 }
 }
</script>






<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <div class="modal-header">
        <h4 class="modal-title">Add to List: </h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <div class="modal-body">
        <form action="add.php" method="POST">
			<div class="form-group">
				<label>Detail:</label>
				<input type="text" class="form-control" placeholder="Enter Details" name="details">
			</div>
			<div class="form-group">
				<label>Public Post?</label>
				<input type="checkbox" name="public" value="yes"/>
			</div>
			<button type="submit" class="btn btn-primary">Add to List</button>
		</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
      
</body>

</html>