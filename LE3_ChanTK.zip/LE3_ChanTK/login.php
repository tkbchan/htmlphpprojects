<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>
<style>
@import url('https://fonts.googleapis.com/css?family=Barlow+Semi+Condensed');

body {
	font-family: 'Barlow Semi Condensed', sans-serif;
	background: url(https://miro.medium.com/max/3002/1*dP81IJq-tGFxy1rIK3RYsg.png) no-repeat center center fixed;
	background-size: cover;
}
.user-img {
	margin-top: -50px;
}
.user-img img {
	height: 100px;
	width: 100px;
}
.main-section {
	margin: 0 auto;
	margin-top: 150px;
	padding: 0;
}
.modal-content {
	background-color: #3e4444;
	opacity: .95;
}
.user-name {
	margin: 10px 0;
}
.user-name h1 {
	font-size: 30px;
	color: #ccd6d7;
}
.form-input button {
	width: 100%;
	margin-bottom: 20px;
}
.btn-success {
	background-color: #2ecc71;
	border: 1px solid #2ecc71;
}
.btn-success:hover {
	background-color: #27ae60;
	border: 1px solid #27ae60;
}
.link-part {
	background-color: #ecf0f1;
	padding: 15px;
	border-radius: 0 0 5px 5px;
	border-top: 1px solid #c2c2c2;
}
</style>

<body>

<form method="POST" action="checklogin.php">
  <div class="modal-dialog text-center">
    <div class="col-sm-9 main-section">
      <div class="modal-content">
        <div class="col-12 user-img">
          <img src="https://lh3.google.com/u/0/d/1ej-zbGFs_hgexGgVNPCWnZeLhqQtwwtH=w1920-h915-iv1">
        </div>
        <div class="col-12 user-name">
          <h1>Login</h1>
        </div>
        <div class="col-12 form-input">
          <form>
			<div class="form-group">
              <input type="text" name="username" class="form-control" placeholder="Enter Username" autocomplete="off" required>
            </div>
            <div class="form-group">
              <input type="password" name="password" class="form-control" placeholder="Enter Password" autocomplete="off" required>
            </div>
            <button type="submit" class="btn btn-danger" name = "submit" value = "Submit">Login</button>

          </form>
        </div>
		<div class="col-12 link-part">
		  <a href="register.php">Don't have an Account? Register Here!</a>
        </div>
      </div>
    </div>
  </div>

</form>





</body>
</html>